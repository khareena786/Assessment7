$(document).ready(function () {
    $(".list-group-item").click(function () {
        var category = $(this).data("category");

        // Load toy details based on the category.
        var toyDetails = getToyDetailsByCategory(category);

        // Update the page with the toy details.
        updateToyDetails(toyDetails);
    });

    // Example toy data (you can load this from a server or define it in your JavaScript):
    var toysData = {
        "Category 1": [
            { title: "Toy 1", price: "$10", description: "car" },
            { title: "Toy 2", price: "$15", description: "bus" }
        ],
        "Category 2": [
            { title: "Toy 3", price: "$20", description: "mickey mouse" },
            { title: "Toy 4", price: "$12", description: "Doremon" }
        ],
        "Category 3": [
            { title: "Toy 5", price: "$18", description: "pokemon" },
            { title: "Toy 6", price: "$25", description: "tom & jerry" }
        ]
    };

    // Function to retrieve toy details for a given category.
    function getToyDetailsByCategory(category) {
        return toysData[category] || [];
    }

    // Function to update the page with toy details.
    function updateToyDetails(toyDetails) {
        var detailsContainer = $("#toy-details-container");
        detailsContainer.empty();

        if (toyDetails.length === 0) {
            detailsContainer.html("<p>No toy details available for this category.</p>");
        } else {
            toyDetails.forEach(function (toy) {
                detailsContainer.append(
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">${toy.title}</h5>
                            <p class="card-text">Price: ${toy.price}</p>
                            <p class="card-text">Description: ${toy.description}</p>
                        </div>
                    </div>
                );
            });
        }
    }
});
